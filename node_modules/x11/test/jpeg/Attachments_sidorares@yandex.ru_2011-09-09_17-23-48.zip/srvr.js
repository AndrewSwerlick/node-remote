var http = require('http');
var fs = require('fs');
var jpgData = fs.readFileSync('./keyboard.jpg');
var htmlData = fs.readFileSync('./example.html');
var jsData = fs.readFileSync('./jpg.js');

var s = http.createServer(function(req,res) {
   console.log(req.url);
   if(req.url == '/')
      res.end(htmlData);
   else if(req.url == '/jpg.js')
      res.end(jsData);
   else
      res.end(jpgData);
   
}).listen(8080);